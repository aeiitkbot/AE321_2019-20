clear all
close all
clc

W = 25*9.81;
s = 0.6;
b = 3;
e = 0.7;
Cd0 = 0.01;
AR = b^2/s;
k = 1/(pi*e*AR);
CL_max = 1.3;
den = 1.225;
Pa = 450;
V = (10:5:50)';
PA = ones(size(V))*Pa;
CL = (2*W)./(den*s*V.^2);
Cd = Cd0 + k*CL.^2;
D =  0.5*den*V.^3*s.*Cd;
Pr = 0.5*den*V.^3*s.*Cd;


figure(1)
plot(V,Pr,':k')
hold on
plot(V,PA,'-r')
xlabel('V (m/s)')
ylabel('P (Watt)')

V_stall = sqrt((2*W)/(den*s*CL_max));




%%
t = 2;
SED = 100;
CL_Pr_min = sqrt((3*Cd0)/k);
V_Pr_min = sqrt((2*W)/(den*s*CL_Pr_min));
Cd_Pr_min = Cd0 + k*CL_Pr_min^2;
Pr_min = 0.5*den*V_Pr_min^3*s*Cd_Pr_min;
ER = Pr_min*t;
W_b = ER/SED;



V_all = [V_Pr_min V_stall]