clear all
close all
clc

W = 8000;
s = 2.72;
T = 2000;
den = DENSITY(-1000);
sigma = den/1.225;
Ta = T*sigma^0.75;
Cd0 = 0.021;
k = 0.015;
CL_max = 1.8;
mue = 0.08;


V_stall = sqrt((2*W)/(den*s*CL_max));
V1 = 1.2*V_stall;
F0 = Ta - mue*W;

D1 = 0.5*1.225*V1^2*s*(Cd0 + k*CL_max^2);
F1 = Ta - D1;
S_1_min = (W/(2*9.81))*((V1^2)/(F0 - F1))*log(F0/F1);

CL_s = mue/(2*k);
V_stall_s = sqrt((2*W)/(den*s*CL_s));
V1_s = 1.2*V_stall_s;
D_s = 0.5*1.225*V1_s^2*s*(Cd0 + k*CL_s^2);
F1_s = Ta - D_s;
S_1_min_s = (W/(2*9.81))*((V1_s^2)/(F0 - F1_s))*log(F0/F1_s);


A = F0;
B = (F1 - F0)/V1^2;

t_1 = (W/(9.81*sqrt(A*B)))*atan(sqrt(B/A)*V1);

h_obs = 15;
gama = asin((T-D1)/W);
S_2 = h_obs/tan(gama);
t_2 = h_obs/(V1*sin(gama));

S = S_1_min + S_2;
t = t_1 + t_2;