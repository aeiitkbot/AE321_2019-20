function [den,P] = DENSITY(z)   
z1 = - z;                               % z is geomentric altitude m
r = 6356766;                            % r is radius of the earth in m.
                                        % h is geopotential altitude in m                            
R = 287;                                % R is universal gas constant in joule per kg-kelvin (J/(kg*K) 
g_0 = 9.81;                             % g_0 is gravity at sea level in meter per square sec (m/s2)


if ((z1 >=0) && (z1 <= 11000))                     % Gradient layer        0-11 km
      h = (r*z1)/(r + z1);
     h1 = 0;
     P1 = 1.01325*(10^5);                     
     T1 = 288.16;                              
   den1 = 1.225;
      a = -0.0065;
      T = T1 + a*(h - h1);
      P = P1*((T/T1)^(-g_0/(a*R))) ;
    den = den1*(T/T1)^((-g_0/(a*R)) - 1) ;  
elseif ((z1 > 11000) && (z1 <= 25000))                % Isothermal layer  11-25 km
      h = (r*z1)/(r + z1);
     h1 = 10981;
     P1 = 22700;
     T1 = 216.78;
   den1 = 0.36480;
      T = T1;
      P = P1*exp(-((g_0*(h - h1))/(R*T)));
    den = den1*exp(-((g_0*(h - h1))/(R*T)));  
   
elseif ((z1 > 25000)&& (z1 <= 47000))                % Gradient layer       25-47 km
      h = (r*z1)/(r + z1);
     h1 = 24902;
     P1 = 2527.3;
     T1 = 216.6601;
   den1 = 0.040639;
      a = 0.003;
      T = T1 + a*(h - h1);
      P = P1*(T/T1)^(-g_0/(a*R)) ;
    den = den1*(T/T1)^((-g_0/(a*R)) - 1);
elseif ((z1 > 47000) && (z1 <= 53000))                % Isothermal layer    47-53 km
      h = (r*z1)/(r + z1);
     h1 = 46655;
     P1 = 125.58;
     T1 = 281.63;
   den1 = 0.00155;
      T = T1;
      P = P1*exp(-((g_0*(h - h1))/(R*T)));
    den = den1*exp(-((g_0*(h - h1))/(R*T)));  
elseif ((z1 > 53000) && (z1 <= 79000))                % Gradient layer       53-79 km
      h = (r*z1)/(r + z1);
     h1 = 52562;
     P1 = 61.493;
     T1 = 282.6601;
   den1 = 0.00075791;
      a = -0.0045;
      T = T1 + a*(h - h1);
      P = P1*((T/T1)^(-g_0/(a*R))) ;
    den = den1*(T/T1)^((-g_0/(a*R)) - 1);
elseif ((z1 > 79000) && (z1 <= 90000))                % Isothermal layer      79-90 km
      h = (r*z1)/(r + z1);
     h1 = (r*79000)/(r + 79000);
     P1 = 1.0039;
     T1 = 165.6601;
   den1 = 6.8610e-006;
      T = T1;
      P = P1*exp(-((g_0*(h - h1))/(R*T)));
    den = den1*exp(-((g_0*(h - h1))/(R*T)));  
elseif ((z1 > 90000)&& (z1 <= 105000))                % Gradient layer       90-105 km
      h = (r*z1)/(r + z1);
     h1 = (r*90000)/(r + 90000);
     P1 = 0.1037;
     T1 = 165.6601;
   den1 = 7.0906*(10^-7);
      a = 0.004;
      T = T1 + a*(h - h1);
      P = P1*((T/T1)^(-g_0/(a*R))) ;
    den = den1*(T/T1)^((-g_0/(a*R)) - 1);
else 
    T = 0.000;
    P = 0.000;
  den = 0.000;
end    
   
return