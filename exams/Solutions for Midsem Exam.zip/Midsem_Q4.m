clear all
close all
clc

W = 50000;
s = 15.63;
Ta = 18750;
den = DENSITY(0);

Cd0 = 0.018;
k = 0.08;
CL_max = 1.5;
n_lim = 6;
CL_a = 5;
aoa0 = -2*(pi/180);

V_stall = sqrt((2*W)/(den*s*CL_max));

z = Ta/(W*sqrt(4*k*Cd0));
CL_R = sqrt(Cd0/k);

VR = sqrt((2*W)/(den*s*CL_R));
FSTR = (9.81*sqrt(2*z-2)/VR);

n_fstr = sqrt(2*z - 1);
phi = acos(1/n_fstr)*(180/pi);

aoa_fstr = ((CL_R/CL_a) + aoa0);
AOA_fstr = aoa_fstr*(180/pi);

R_fstr = VR^2/(9.81*sqrt(n_fstr^2 - 1));

