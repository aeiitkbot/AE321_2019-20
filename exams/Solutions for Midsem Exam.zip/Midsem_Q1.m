clear all
close all
clc
%%
%--------------Question 1a-------------------------------------------------
W = 10000;
W_s = 1000;
s = W/W_s;
T = 1000;
V_stl = 36;

CL_M = (2*W_s)/(1.225*V_stl^2);
CL_m = -0.8;
k = 0.025;
Cd0 = 0.015;

n_Lim = 6;
n_lim = -2;
V_CR = sqrt((2*n_Lim*W_s)/(1.225*CL_M));
V_cr = sqrt((2*n_lim*W_s)/(1.225*CL_m));

z = T/(W*sqrt(4*k*Cd0));
CL_R = sqrt(Cd0/k);
V_R = sqrt((2*W_s)/(1.225*CL_R));
V_max = sqrt(z + sqrt(z^2 - 1))*V_R;
V_ult = 1.2*V_max;

% for i =1:1:2
% for  V = 0:20:V_CR
% if i == 1
%     CL = CL_M;
% else
%     CL = CL_m
% end 
% L(i,1) = 0.5*1.225*V^2*s*CL;
% n = L/W;
V_p = (0:1:V_CR)';
L_p = 0.5*1.225*V_p.^2*s*CL_M;
n_p = L_p/W;
V_p1 = [V_p;V_max;V_ult;V_ult];
n_p1 = [n_p;n_Lim;n_Lim;0];

V_n = (0:1:V_cr)';
L_n = 0.5*1.225*V_n.^2*s*CL_m;
n_n = L_n/W;
V_n1 = [V_n;V_max;V_ult;V_ult];
n_n1 = [n_n;n_lim;n_lim;0];


figure(1)
plot(V_p1,n_p1,'-r')
hold on
plot(V_n1,n_n1,'-b')
xlabel('V (m/s)')
ylabel('n')
grid on

%%
%--------------Question 1b-------------------------------------------------

n1 = 1;
n2 = cos(15*(pi/180));
n3 = cos(-5*(pi/180));
n4 = 1/cos(45*(pi/180));

n_Q2 = [n1 n2 n3 n4];

display(n_Q2)



















