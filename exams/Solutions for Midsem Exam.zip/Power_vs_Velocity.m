clear all
close all
clc

V = (5:5:130)';

w = 50000;                  % weight of the aircraft in Newtons
s = 30;                     % wing planform area in m^2
Pa(1:size(V),1) = 840*1000;              % Maximum power available in KW
n_pr = 0.85;                % propeller efficiency 
PA = n_pr*Pa;
den = 1.225;                % density of air at sea level

CL_max = 1.75;              % Maximum ceoefficient 
Cd0 = 0.025;
k = 0.05;

for i=1:1:size(V)
CL(i,1) = (2*(w/s))/(den*V(i,1)^2);
Cd(i,1) = Cd0 + k*CL(i,1)^2;     % Drag polar
 D(i,1) = 0.5*den*V(i,1)^2*s*Cd(i,1);
PR(i,1) = D(i,1)*V(i,1);
end

V_stall = sqrt((2*(w/s))/(den*CL_max));

CL_Pmin = sqrt((3*Cd0)/k);
Cd_Pmin = 4*Cd0;

V_Pmin = sqrt((2*(w/s))/(den*CL_Pmin));


display(V_stall)
display(V_Pmin)

figure(1)
plot(V,PR,'*:k')
hold on
plot(V,PA,'-r')
xlabel('V, m/s')
ylabel('Power, W')